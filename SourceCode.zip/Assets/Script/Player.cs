using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class Player : MonoBehaviour
{
    public float moveSpeed = 2f;
    Rigidbody2D rb;
    AudioManager audioManager;


    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
 audioManager = GameObject.FindGameObjectWithTag("Audio").GetComponent<AudioManager>();
    }

    void Update()
    {
        if (Input.GetMouseButton(0))
        {


            Vector3 touchPos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

            if(touchPos.x < 0)
            {
                rb.AddForce(Vector2.left * moveSpeed);
            }else
            {
                rb.AddForce(Vector2.right * moveSpeed);

            }

        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag =="Meteor")
        {
            audioManager.PlaySFX(audioManager.death);
            SceneManager.LoadScene(2);
        }
    }



}
